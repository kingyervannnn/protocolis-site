# Protocolis benchmark: replication kit

This kit holds the material behind the results published at protocolis.co and in the paper *Solid-State Web Execution:
Compiling Web Applications into Verified Operations for AI Agents*. With it a reader can recompute every completion
figure and run the same tasks on any system.

## Files

- `tasks.csv`: the tasks. 20 short, 40 medium and 21 long. Each has its start page and its text. Short and
  medium tasks also carry the page the run must end on and the answers that are accepted.
- `outcomes.csv`: one line for every counted run, 3,443 in all. It gives the task, the system, the model, whether the
  system said it had finished, and whether the run was judged complete.
- `cells.csv`: the 81 published cells, one per task set, model size and system: completed and attempted runs, cost,
  time and tokens per completed task.
- `JUDGING.md`: how a run is judged in each task set, and the key points the judge checks on each long task.

## How to read it

A cell is one system on one model on one task set. Its completion is the number of lines in `outcomes.csv` for that
cell with `judged_complete` = yes, over the number of lines for that cell. Those two numbers are the `completed` and
`attempted` columns of `cells.csv`, and they were checked against each other when this kit was built.

Short and medium tasks were run more than once per system, so a task can appear several times in a cell; `attempt`
numbers them. Long tasks were run once.

Not every cell has the same number of long runs. The two rules in `JUDGING.md` explain why: tasks on a site that
refused every system were replaced, and a single run that ended on a site's block page is left out of that system's count.
The long tasks come from two public sets, WebVoyager and Mind2Web-Live; `tasks.csv` names the source of each.

Two Protocolis cells on the short set (Tools, frontier model) are counted as published, on the page check: the run
ended on the required page showing an accepted answer. On the answer check as well, one run in each would not count.

In two Protocolis cells on the medium set (Agents, strong model), both runs of one task ended on the site's robot check
and were measured again; the second measurement is the one counted, as in the published record.

Every Protocolis run is a first visit: the system kept no memory of any site and has no site-specific code.

## What is not here

The engine's source code and internal records are not published. The recorded runs are provided on request for
replication. Access to the system itself, for running it on sites of your own choosing, can be requested at protocolis.co.

Built from the published record as it stood on 20 November 2026.
