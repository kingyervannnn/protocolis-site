# How each run was judged

One rule per task set. The same rule was applied to every system.

## Short and medium tasks

A run is complete when all of these hold: the system finished; the page it ended on matches the pattern in
`final_page_must_match`; that page shows an answer matching `accepted_answer_pattern`; and the answer the system gave
also matches `accepted_answer_pattern` (both patterns are in `tasks.csv`). Every attempt is counted. On the medium set,
a run whose evidence could not be captured is left out for every system, and the published record of the row says how many.

## Long tasks

Judged after the run by WebJudge, from the Online-Mind2Web project, with its own prompts and its strict column. One
judge model, gpt-5.6-luna at medium reasoning, ruled on every run of every system. The judge sees the run's actions and
screenshots. It does not see the answer the system gave. A run in which the system itself reports that it was blocked
is not complete.

The key points the judge checks were written once per task and used for every system. They are listed below.

Two rules decide which runs are counted. A task whose site refused every system (the two Amazon tasks) is left out for
every system and replaced from a list fixed before any run. A single run that ended on a site's block page or robot
check is left out of that system's count; the published record of the row names it.

On the frontier model, a long run that spent more than $2.00 on model calls is counted as not complete, for every
system, and its spend stays in the cost. One run is affected: a Stagehand run (wv-ESPN--22) that the judge accepted.

## Key points for the long tasks

### wv-Google_Search--4

Show most played games in Steam. And tell me the number of players in In game at this time

1. Open Steam’s most-played games list.
2. Filter by highest player count.
3. Report the current number of players marked “In-Game.”

### wv-ESPN--22

Find the latest Team transactions in the NBA within the past week.

1. Find NBA team transactions.
2. The transactions shown are from the past week.
3. The transactions are shown latest first.

### wv-Cambridge_Dictionary--9

Look up the British pronunciation of the word "euphoria" and find an example sentence using that word on the Cambridge Dictionary.

1. Look up the British pronunciation of “euphoria.”
2. Find an example sentence using “euphoria” on the Cambridge Dictionary.

### wv-GitHub--8

Look up the latest stable release version of Vuex and find out when it was published.

1. Look up Vuex releases.
2. The release shown is the latest stable release (the one GitHub marks "Latest").
3. Identify its version number.
4. Find when it was published.

### wv-Coursera--23

Find a course on Coursera about 'Artificial Intelligence Ethics', which has a duration of less than 5 weeks and has been rated 4.5 stars or higher. Provide the course name and the instructor's name.

1. Find a course on Coursera about “Artificial Intelligence Ethics.”
2. Filter for courses with a duration of less than 5 weeks.
3. The course shown is rated 4.5 stars or higher.
4. Provide the course name.
5. Provide the instructor’s name.

### wv-BBC_News--12

Find a picture in the travel section that contains food, tell me what the food is called and what region it comes from.

1. Find a picture in the travel section that contains food.
2. Identify what the food is called.
3. Identify what region the food comes from.

### wv-Apple--19

On Apple's website, what is the slogan for the Mac and what is the slogan for the Macbook pro.

1. Find the slogan for the Mac on Apple's website.
2. Find the slogan for the MacBook Pro on Apple's website.

### wv-ESPN--4

Check ESPN for the final scores of NBA games that were played yesterday.

1. Check ESPN.
2. Identify NBA games played yesterday.
3. Retrieve the final scores for those games.

### wv-BBC_News--41

Find Golf in BBC News, check the Leaderboard at this point in Women's Majors and count which country has the most players in the top 20? Which player has the best score amongst the Australian players and in what place.

1. Find Golf in BBC News.
2. Check the Women’s Majors leaderboard.
3. The top 20 of the leaderboard are shown.
4. Count the players from each country.
5. The answer identifies which country has the most players in the top 20.
6. Identify the Australian player with the best score.
7. Determine that player’s place.

### wv-Wolfram_Alpha--6

Simplify x^5-20x^4+163x^3-676x^2+1424x-1209 so that it has fewer items.

1. Simplify the polynomial \(x^5-20x^4+163x^3-676x^2+1424x-1209\).
2. Express the result with fewer terms.

### m2wl-97

Find the most popular movies and showcase those with the highest IMDb ratings on imdb

1. Find the most popular movies on IMDb.
2. Filter by highest IMDb ratings.
3. Showcase the selected movies.

### m2wl-78

Browse through the Las Vegas city guide and find message services nearest to Henderson, the service provider should have a BBB rating of A+ on yellowpages

1. Browse the Las Vegas city guide.
2. Find message services nearest to Henderson.
3. Filter by closest.
4. Verify the service provider has a BBB rating of A+ on Yellowpages.

### m2wl-98

Show list of popular businesses in Cleveland on yellowpages.

1. Open Yellowpages.
2. Search for businesses in Cleveland.
3. The businesses shown are listed as popular businesses in Cleveland.
4. Show the list of results.

### m2wl-37

Find me the cheapest external HD for an Xbox One on gamestop.

1. Search GameStop.
2. Find external hard drives compatible with Xbox One.
3. Filter by lowest price.

### m2wl-66

Compare Apple watches and learn more about the ultra version on apple

1. Compare Apple Watches.
2. Learn more about the Apple Watch Ultra version on Apple’s website.

### m2wl-76

What are the food festivals happening in Colorado This weekend? on eventbrite

1. Find food festivals happening this weekend.
2. Limit results to events in Colorado.
3. Search on Eventbrite.

### m2wl-19

Find the weight of baggage allowance for economy class on qatarairways

1. Find the baggage allowance weight for Economy Class on Qatar Airways.

### m2wl-39

Show me products from Calvin Klein brand menswear list on kohls.

1. Open the menswear product list on Kohl’s.
2. Filter the list to the Calvin Klein brand.
3. Show the matching products.

### wv-Google_Map--4

Plan a trip from Boston Logan Airport to North Station.

1. Plan a trip from Boston Logan Airport to North Station.

### wv-Allrecipes--18

Find a recipe for a vegetarian lasagna that has over 300 reviews and an average rating of 4.5 or higher on Allrecipes.

1. Find a vegetarian lasagna recipe on Allrecipes.
2. Ensure the recipe has over 300 reviews.
3. Ensure the recipe has an average rating of 4.5 or higher.

### wv-Coursera--21

Search for an online course on Coursera about 'Digital Marketing', suitable for beginner-level learners. Specify the course duration, the main learning outcomes, and the institution offering the course.

1. Search Coursera for an online course about “Digital Marketing.”
2. Ensure the course is suitable for beginner-level learners.
3. Specify the course duration.
4. Identify the main learning outcomes.
5. Identify the institution offering the course.
